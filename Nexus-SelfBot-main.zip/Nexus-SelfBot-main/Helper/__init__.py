__title__ = 'Nexus selfbot'
__author__ = 'vatosv2/vatos.py'
__copyright__ = 'discord.gg/nexustools'
__version__ = '1.0.0'

from .ColorUtils import ColorUtils